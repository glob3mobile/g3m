/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2011, PostgreSQL Global Development Group
*
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc3;

import org.postgresql.ds.PGPoolingDataSource;

public class Jdbc3PoolingDataSource extends PGPoolingDataSource
{
}
