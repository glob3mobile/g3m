/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2011, PostgreSQL Global Development Group
*
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc2.optional;

import org.postgresql.ds.PGSimpleDataSource;

public class SimpleDataSource extends PGSimpleDataSource
{
}
